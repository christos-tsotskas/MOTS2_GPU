/*
 * mapping_tuple.cpp
 *
 *  Created on: Jan 19, 2014
 *      Author: ctsotskas
 */

#include "mapping_tuple.h"


mapping_tuple::mapping_tuple(Point2 P_arg, ObjFunction2 O_arg):Pnt(P_arg), ObjF(O_arg){

}
